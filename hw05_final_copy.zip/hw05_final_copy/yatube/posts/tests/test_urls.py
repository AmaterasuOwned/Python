
from django.contrib.auth import get_user_model
from django.test import TestCase, Client
from posts.models import Post, Group
from http import HTTPStatus

User = get_user_model()


class PostsPagesTests(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.author = User.objects.create_user(username="VsevolodV")
        cls.group = Group.objects.create(
            title="test_title",
            description="test_description",
            slug="test-slug",
        )
        cls.post = Post.objects.create(
            text="test_post", author=cls.author, group=cls.group
        )

    def setUp(self):
        self.authorized_author = Client()
        self.authorized_author.force_login(self.author)
        self.guest_client = Client()

    def test_unexisting_url_exists_at_desired_location(self):
        """Страница /unexisting_page/ недоступна."""
        response = self.authorized_author.get('/unexisting_page/')
        self.assertEqual(response.status_code, HTTPStatus.NOT_FOUND)

    def test_create_url_redirect_anonymous_on_admin_login(self):
        """Страница /create/ перенаправляет анонимного пользователя
        на страницу логина.
        """
        response = self.guest_client.get('/create/', follow=True)
        self.assertRedirects(
            response, '/auth/login/?next=/create/')

    def test_posts_edit_url_redirect_anonymous_on_admin_login(self):
        """/posts/<post_id>/edit/ перенаправляет анонимного пользователя
        """
        response = self.client.get('/posts/1/edit/', follow=True)
        self.assertRedirects(
            response, ('/auth/login/?next=/posts/1/edit/'))

    def test_urls_uses_correct_template(self):
        """URL-адрес использует соответствующий шаблон."""
        templates_url_names = {
            '/': 'posts/index.html',
            '/group/test-slug/': 'posts/group_list.html',
            '/create/': 'posts/create_post.html',
            '/posts/1/edit/': 'posts/create_post.html',
            '/profile/VsevolodV/': 'posts/profile.html',
        }
        for template, url in templates_url_names.items():
            with self.subTest(template=template):
                response = self.authorized_author.get(template)
                self.assertEqual(response.status_code, HTTPStatus.OK)
                self.assertTemplateUsed(response, url)
