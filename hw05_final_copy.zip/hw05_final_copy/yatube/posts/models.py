from django.db import models
from django.contrib.auth import get_user_model
from core.models import CreatedModel
from django.urls import reverse

User = get_user_model()
NUMBERS_OF_SYMBOLS: int = 15


class Group(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.title}"


class Post(CreatedModel):
    text = models.TextField("Текст поста", help_text="Введите текст поста")
    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        verbose_name="Автор",
        related_name="posts",
    )

    group = models.ForeignKey(
        Group,
        on_delete=models.SET_NULL,
        related_name="posts",
        null=True,
        blank=True,
        max_length=200,
        verbose_name="Группа",
        help_text="Выберите группу",
    )
    image = models.ImageField("Картинка", upload_to="posts/", blank=True)

    def __str__(self):
        return self.text[:NUMBERS_OF_SYMBOLS]

    class Meta:
        ordering = ["-pub_date"]
        verbose_name = "Пост"
        verbose_name_plural = "Посты"


class Comment(CreatedModel):
    post = models.ForeignKey(
        Post, on_delete=models.CASCADE, related_name="comments", null=True
    )
    text = models.TextField(
        "Комментарий", null=True, help_text="Введите текст комментария"
    )
    author = models.ForeignKey(
        User, on_delete=models.CASCADE, verbose_name="Автор", null=True
    )

    def __str__(self):
        return f"{self.text[:NUMBERS_OF_SYMBOLS]} by user {self.author}"


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    def get_absolute_url(self):
        return reverse(
            "accounts:profile", kwargs={"username": self.user.username}
        )


class Follow(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="follower"
    )
    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="following"
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'author'],
                name='unique_following'
            )
        ]

    def __str__(self):
        return "{} follows {}".format(self.user, self.author)
