from django.core.paginator import Paginator


NUMBERS_OF_POSTS: int = 10


# я понял почему у меня не работало, потому что в индексе
# он обновлял контекст, а тот пустой)
def get_page(queryset, request):
    paginator = Paginator(queryset, NUMBERS_OF_POSTS)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return page_obj
